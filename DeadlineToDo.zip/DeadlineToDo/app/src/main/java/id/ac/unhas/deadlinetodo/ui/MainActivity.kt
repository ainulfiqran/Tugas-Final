package id.ac.unhas.deadlinetodo.ui

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import id.ac.unhas.deadlinetodo.R
import id.ac.unhas.deadlinetodo.db.AppDatabase
import id.ac.unhas.deadlinetodo.db.deadline.Constant
import id.ac.unhas.deadlinetodo.db.deadline.Deadline
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : AppCompatActivity() {

    private val db by lazy { AppDatabase(this) }
    lateinit var deadlineAdapter: DeadlineAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        setupView()
        setupListener()
        setupRecyclerView()
    }

    override fun onResume() {
        super.onResume()
        loadData()
    }

    private fun loadData(){
        CoroutineScope(Dispatchers.IO).launch {
            deadlineAdapter.setData(db.deadlineDao().getDeadlines())
            withContext(Dispatchers.Main) {
                deadlineAdapter.notifyDataSetChanged()
            }
        }
    }

    private fun setupView (){
        supportActionBar!!.apply {
            title = "Deadline To Do"
        }
    }

    private fun setupListener(){
        button_create.setOnClickListener {
            intentEdit(Constant.TYPE_CREATE, 0)
        }
    }

    private fun setupRecyclerView () {

        deadlineAdapter = DeadlineAdapter(
            arrayListOf(),
            object : DeadlineAdapter.OnAdapterListener {
                override fun onClick(deadline: Deadline) {
                    intentEdit(Constant.TYPE_READ, deadline.id)
                }

                override fun onUpdate(deadline: Deadline) {
                    intentEdit(Constant.TYPE_UPDATE, deadline.id)
                }

                override fun onDelete(deadline: Deadline) {
                    deleteAlert(deadline)
                }

            })

        list_deadline.apply {
            layoutManager = LinearLayoutManager(applicationContext)
            adapter = deadlineAdapter
        }

    }

    private fun intentEdit(intent_type: Int, deadline_id: Int) {
        startActivity(
            Intent(this, EditActivity::class.java)
                .putExtra("intent_type", intent_type)
                .putExtra("deadline_id", deadline_id)

        )

    }

    private fun deleteAlert(deadline: Deadline){
        val dialog = AlertDialog.Builder(this)
        dialog.apply {
            setTitle("Konfirmasi Hapus")
            setMessage("Yakin hapus ${deadline.title}?")
            setNegativeButton("Batal") { dialogInterface, i ->
                dialogInterface.dismiss()
            }
            setPositiveButton("Hapus") { dialogInterface, i ->
                CoroutineScope(Dispatchers.IO).launch {
                    db.deadlineDao().deleteDeadline(deadline)
                    dialogInterface.dismiss()
                    loadData()
                }
            }
        }

        dialog.show()
    }
}