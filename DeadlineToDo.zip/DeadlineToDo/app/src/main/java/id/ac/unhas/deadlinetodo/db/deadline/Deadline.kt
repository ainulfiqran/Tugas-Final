package id.ac.unhas.deadlinetodo.db.deadline

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "deadline")
data class Deadline(
    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "id")
    val id: Int = 0,
    @ColumnInfo(name = "deadline")
    var deadline: String,
    @ColumnInfo(name = "title")
    var title: String
)