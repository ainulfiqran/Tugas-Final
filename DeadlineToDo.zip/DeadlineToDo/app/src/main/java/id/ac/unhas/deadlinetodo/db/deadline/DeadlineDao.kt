package id.ac.unhas.deadlinetodo.db.deadline

import androidx.room.*

@Dao
interface DeadlineDao {
    @Insert
    suspend fun addDeadline(deadline: Deadline)

    @Query("SELECT * FROM deadline ORDER BY id DESC")
    suspend fun getDeadlines() : List<Deadline>

    @Query("SELECT * FROM deadline WHERE id=:deadline_id")
    suspend fun getDeadline(deadline_id: Int) : List<Deadline>

    @Update
    suspend fun updateDeadline(deadline: Deadline)

    @Delete
    suspend fun deleteDeadline(deadline: Deadline)
}