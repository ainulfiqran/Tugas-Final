package id.ac.unhas.deadlinetodo.ui

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import id.ac.unhas.deadlinetodo.R
import id.ac.unhas.deadlinetodo.db.deadline.Deadline
import kotlinx.android.synthetic.main.adapter_main.view.*

class DeadlineAdapter (var deadlines: ArrayList<Deadline>, var listener: OnAdapterListener) :
    RecyclerView.Adapter<DeadlineAdapter.DeadlineViewHolder>(){

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): DeadlineViewHolder {
        return DeadlineViewHolder(
            LayoutInflater.from(parent.context)
                .inflate(
                    R.layout.adapter_main,
                    parent,
                    false
                )
        )
    }

    override fun getItemCount() = deadlines.size

    override fun onBindViewHolder(holder: DeadlineViewHolder, position: Int) {
        val deadline = deadlines[position]
        holder.view.text_title.text = deadline.title
        holder.view.text_title.setOnClickListener {
            listener.onClick(deadline)
        }
        holder.view.icon_edit.setOnClickListener {
            listener.onUpdate(deadline)
        }
        holder.view.icon_delete.setOnClickListener {
            listener.onDelete(deadline)
        }
    }

    class DeadlineViewHolder(val view: View) : RecyclerView.ViewHolder(view)

    fun setData(newList: List<Deadline>) {
        deadlines.clear()
        deadlines.addAll(newList)
    }

    interface OnAdapterListener {
        fun onClick(deadline: Deadline)
        fun onUpdate(deadline: Deadline)
        fun onDelete(deadline: Deadline)
    }
}