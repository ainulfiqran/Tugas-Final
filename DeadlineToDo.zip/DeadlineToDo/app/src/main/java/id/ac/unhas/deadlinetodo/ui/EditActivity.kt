package id.ac.unhas.deadlinetodo.ui

import android.os.Bundle
import android.view.View
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity
import id.ac.unhas.deadlinetodo.R
import id.ac.unhas.deadlinetodo.db.AppDatabase
import id.ac.unhas.deadlinetodo.db.deadline.Constant
import id.ac.unhas.deadlinetodo.db.deadline.Deadline
import kotlinx.android.synthetic.main.activity_edit.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.util.*

class EditActivity : AppCompatActivity() {

    private val db by lazy { AppDatabase(this) }
    private var deadlineId = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_edit)
        setupView()
        setupLstener()
    }

    private fun setupView(){
        supportActionBar!!.setDisplayHomeAsUpEnabled(true)
        when (intentType()) {
            Constant.TYPE_CREATE -> {
                supportActionBar!!.title = "New Deadline"
                button_save.visibility = View.VISIBLE
                button_update.visibility = View.GONE
            }
            Constant.TYPE_READ -> {
                supportActionBar!!.title = "Your Deadline"
                button_save.visibility = View.GONE
                button_update.visibility = View.GONE
                getDeadline()
            }
            Constant.TYPE_UPDATE -> {
                supportActionBar!!.title = "Update Deadline"
                button_save.visibility = View.GONE
                button_update.visibility = View.VISIBLE
                getDeadline()
            }
        }
    }

    private fun setupLstener(){
        button_save.setOnClickListener {
            CoroutineScope(Dispatchers.IO).launch {
                db.deadlineDao().addDeadline(
                    Deadline(
                        0,
                        edit_title.text.toString(),
                        edit_deadline.text.toString()
                    )
                )
                finish()
            }
        }
        button_update.setOnClickListener {
            CoroutineScope(Dispatchers.IO).launch {
                db.deadlineDao().updateDeadline(
                    Deadline(
                        deadlineId,
                        edit_title.text.toString(),
                        edit_deadline.text.toString()
                    )
                )
                finish()
            }
        }
    }

    private fun getDeadline(){
        deadlineId = intent.getIntExtra("deadline_id", 0)
        CoroutineScope(Dispatchers.IO).launch {
            val deadlines = db.deadlineDao().getDeadline(deadlineId).get(0)
            edit_title.setText( deadlines.title )
            edit_deadline.setText( deadlines.deadline )
        }
    }

    override fun onSupportNavigateUp(): Boolean {
        finish()
        return super.onSupportNavigateUp()
    }

    private fun intentType(): Int {
        return intent.getIntExtra("intent_type", 0)
    }
}